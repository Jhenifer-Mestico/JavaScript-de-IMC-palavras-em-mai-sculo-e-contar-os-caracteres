console.log('Eu tinha uma vida antes de ser programadora'.toUpperCase()); /*caixa alta OK*/

var texto = "Eu tinha uma vida antes de ser programadora";
var tamanho = texto.length;
document.write("Este texto contém " + tamanho + " caracteres."); /*conta os caracteres OK*/

var nome = prompt("Digite o seu nome: ");
var altura = parseInt (prompt( nome + "Qual a sua altura?")); /*IMC ver ainda ta dando erro*/
var peso = parseInt (prompt ( nome + "Qual o seu peso?"));   
/*imc = peso/(altura*altura);*/
imc = peso / (Math.pow(altura,2));
alert("Seu peso é:" + imc); 